package com.bookclub.service.dao;
import com.bookclub.Model.Book;
import com.bookclub.service.GenericDao;

public interface BookOfTheMonthDao extends GenericDao<Book, String>{

    
}
