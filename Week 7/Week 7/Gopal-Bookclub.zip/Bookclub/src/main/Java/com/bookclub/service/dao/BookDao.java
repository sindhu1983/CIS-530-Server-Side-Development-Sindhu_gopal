package com.bookclub.service.dao;

public interface BookDao extends GenericDao<Book, String>{

}
